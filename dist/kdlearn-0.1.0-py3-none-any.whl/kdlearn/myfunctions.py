'''
PUT FUNCTION HERE !!

Author Davinci
'''


def helloworld(name):
    return "KDlearn :" + name
